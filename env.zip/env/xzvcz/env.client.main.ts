import { getEnv } from "akanjs/base";

import type { AppClientEnv } from "./env.client.type";

export const env: AppClientEnv = {
  ...getEnv(),
} as const;

